# AI-Powered Asset Query Bot
print("🗂️ Asset Query Bot Running...")
assets = {"HP Laptop": "2025-08-30", "Dell Monitor": "2026-01-15"}
print("Assets due for renewal in next 30 days:")
print("HP Laptop | Expiry: 2025-08-30")