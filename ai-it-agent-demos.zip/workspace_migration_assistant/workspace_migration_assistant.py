# Google Workspace Migration Assistant
print("📧 Workspace Migration Assistant")
query = input("Ask Migration Query: ")
print("To move Outlook emails to Gmail: Export PST → Import via Google Workspace Migration Tool.")