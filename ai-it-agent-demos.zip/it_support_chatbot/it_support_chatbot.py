# IT Support Chatbot Agent
print("🤖 IT Support Chatbot Agent is running...")
user = input("Ask IT Support Query: ")
print("Bot: Please reset your password at https://accounts.google.com")